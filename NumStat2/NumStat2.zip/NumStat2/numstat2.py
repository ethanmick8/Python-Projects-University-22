# Assignment: Number Stats 2
# Class: INFOTC 4401
# Instructor: Dale Musser
# Author: Ethan Mick

# This function retrieves the numbers from the file that is being accessed and stores
# them as integers in a list called "numbers"
def retrieve_filedata( filename ):
    numbers = []

    # "with --> as file will authomatically close the file when the block is exited"
    with open( filename, 'r' ) as file:

        # This reads the lines of the file as a list of strings
        string_numbers = file.readlines()

        # Now, we convert them to ints and store them in the numbers list
        for number in string_numbers:
            numbers.append( int(number) )

        # Check for the special case that no numbers are in the file, aka numbers4.txt was used
        if( len(numbers) == 0 ):
            print( "There are no numbers in numbers4.txt\n" )
            return 0

    return numbers
            
# This function calls retrieve_filedata after ensuring that the user's requested file can
# be opened/accessed. It then proceeds to calculate a wide range of statistics regarding the
# numbers in the file, and prints those values out.
def get_and_display_filestats( filename ): 

    # Initialization Phase
    Count = 0
    Sum = 0
    Average = 0
    Max = 0
    Min = 0
    Range = 0
    Median = 0
    Mode = []
    numbers = []

    # Check to make sure the file passed in exists/can be opened
    try:
        numbers = retrieve_filedata( filename ) 
        if( numbers == 0 ): # error checking for numbers4.txt
            return
    except Exception as error: # didn't realize I could write exceptions this way, seems better
        print(error)
        return 

    # Print the name of the file (I don't think this is required, I just like to be thorough)
    print( "'Name of the File: ", filename )

    # Sort the list. This is necessary in order to calculate median and mode of the numbers
    # Note: the default for sort() is ascending order
    numbers.sort()

    # Calculate the length of the list (# of numbers) and store it in the variable Count
    Count = len( numbers )

    # Calculate the index that is in the middle of the list
    index = Count // 2

    # use sorted() for the calculated index to determine the value of the mean. The calculations
    # are slightly different depending on whether the length of the list is even or odd
    if Count % 2:
        Median = sorted(numbers)[index]
    else:
        Median = (sum(sorted(numbers)[index-1:index+1]) / 2)

    # Create a dictionary for the numbers in the file in order to calculate the mode
    number_counts = {}

    # Loop through the numbers in the number list, incrementing the count for each
    # number every time that specific number is encountered.
    for number in numbers:
        if number in number_counts:
            number_counts[number] += 1
        else:
            number_counts[number] = 1

    # Determine the maximum freqnecy count
    max_freq = 0
    for number in number_counts:
        frequency = number_counts[number]
        if( frequency >= max_freq ):
            max_freq = frequency

    # Create a list to store the Mode value(s)
    Mode = []

    # Loop through the numbers obtained from the file
    for number in numbers:
        # check to see if the number occurs in afrequency equal to the highest occuring
        # freqnecy determined above. If so, add the number to Mode.
        if( max_freq == number_counts[number] ):
            if number in Mode: # Ignore potential duplicates
                continue
            else:
                Mode.append( number )

    # Do the calculations for the remaining stats using either corresponding Python functions 
    # or simple arithmetic
    Sum = sum( numbers )
    Max = max( numbers )
    Min = min( numbers )
    Average = Sum / Count
    Range = Max - Min

    # Display the calculated data for the numbers in the list
    print( "Sum: ", Sum )
    print( "Count: ", Count )
    print( "Average: ", Average )
    print( "Maximum: ", Max )
    print( "Minimum: ", Min )
    print( "Range: ", Range )
    print( "Median: ", Median )
    print( "Mode: ", Mode )

def main():
    print( 'Welcome to the Number Statistics File Reader Program (2.0)!\n')
    while(True):
        filename = input( "Please enter the path of the file you would like to process: " )
        get_and_display_filestats( filename )

        # Check to see if the user wants to generate another report    
        AnotherRead = input( "Would you like to evaluate another file (y/n)?: " )
        if( AnotherRead != "y" ):
            break
        else:
            print('') # input separator (borrowed this from your code example for numstat from last week)

main() # run the program